/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author humai
 */
public class NewClass {
    public static void main(String[] args) {
        int ans = 9/2;
        System.out.println(ans);
    }
}
