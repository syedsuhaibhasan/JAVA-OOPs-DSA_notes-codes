/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.javaoop.mavenproject2.OOPs;
import com.javaoop.mavenproject2.OOPs.employees;
/**
 *
 * @author humai
 */
public class displayemloyeedetails {
    public static void main(String[] args) {
        employees emp = new employees(6000,50,"ivrahim");
        System.out.println(emp.employeedetails());
        
    }
}
