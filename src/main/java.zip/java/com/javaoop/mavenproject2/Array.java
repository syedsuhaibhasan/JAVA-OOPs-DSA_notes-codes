/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.javaoop.mavenproject2;


/**
 *
 * @author humai
 */
public class Array {
    public static void main(String[] args) {
        methods obj = new methods(2);
       
        obj.insertArray(5);
        obj.insertArray(6);
        obj.insertArray(4);
        obj.displayArray();
    }
}
