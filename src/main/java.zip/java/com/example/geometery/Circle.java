/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.geometery;

/**
 *
 * @author humai
 */
public class Circle {
   public double radius;
   public final float PIE =(float) 3.142;
   public Circle(double radius){
   this.radius=radius;
   }
}
