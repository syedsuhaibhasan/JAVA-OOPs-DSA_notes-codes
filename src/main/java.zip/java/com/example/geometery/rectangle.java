/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.geometery;

/**
 *
 * @author humai
 */
public class rectangle {
    public float length,width;
    public rectangle(float length,float width){
    this.length=length;
    this.width=width;
    }
}
